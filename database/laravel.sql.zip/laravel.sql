-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: mysql
-- Tiempo de generación: 26-11-2024 a las 16:10:36
-- Versión del servidor: 9.1.0
-- Versión de PHP: 8.2.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `laravel`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cache`
--

CREATE TABLE `cache` (
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `cache`
--

INSERT INTO `cache` (`key`, `value`, `expiration`) VALUES
('25247913abf6300777fdabe1c7c46e33', 'i:1;', 1732620905),
('25247913abf6300777fdabe1c7c46e33:timer', 'i:1732620905;', 1732620905),
('291e94f551f9d0ee30a26dbe1bd88408', 'i:1;', 1730590299),
('291e94f551f9d0ee30a26dbe1bd88408:timer', 'i:1730590299;', 1730590299),
('bbcbfc984ed2dba6210c981bacbdaa2c', 'i:1;', 1730633935),
('bbcbfc984ed2dba6210c981bacbdaa2c:timer', 'i:1730633935;', 1730633935);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cache_locks`
--

CREATE TABLE `cache_locks` (
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `categories`
--

CREATE TABLE `categories` (
  `id` bigint UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `logo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ico` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `logo_color` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `primary_color` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `secondary_color` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `opacidad` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `categories`
--

INSERT INTO `categories` (`id`, `name`, `logo`, `ico`, `logo_color`, `primary_color`, `secondary_color`, `opacidad`, `description`, `created_at`, `updated_at`) VALUES
(1, 'Laravel', 'laravel-logo.svg', 'ti-laravel', '#ffffff', '#FF2D20', '#000000', '66', 'Este es el texto descriptivo de la categoría de laravel.', NULL, NULL),
(2, 'php', 'php-logo.svg', 'ti-file-type-php', '#ffffff', '#10478e', '#a9c1df', 'cc', NULL, NULL, NULL),
(3, 'html', 'html5.svg', 'ti-brand-html5', '#000000', '#E34F26', '#615fc4', 'CC', 'Descripción del Hache Te eme ele 5', NULL, NULL),
(4, 'css', 'css3.svg', 'ti-brand-css3', '#ffffff', '#1572B6', '#505558', '66', NULL, NULL, NULL),
(5, 'django', 'django.svg', 'ti-brand-django', '#ffffff', '#092E20', '#092E2003', NULL, NULL, NULL, NULL),
(6, 'python', 'python.svg', 'ti-brand-python', '#ffffff', '#3776AB', '#3776AB', '', '', NULL, NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `category_post`
--

CREATE TABLE `category_post` (
  `id` bigint UNSIGNED NOT NULL,
  `post_id` bigint UNSIGNED NOT NULL,
  `category_id` bigint UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `category_post`
--

INSERT INTO `category_post` (`id`, `post_id`, `category_id`, `created_at`, `updated_at`) VALUES
(1, 2, 1, NULL, NULL),
(2, 3, 2, NULL, NULL),
(7, 5, 3, NULL, NULL),
(8, 1, 4, NULL, NULL),
(9, 4, 5, NULL, NULL),
(10, 6, 6, NULL, NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint UNSIGNED NOT NULL,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `general_config`
--

CREATE TABLE `general_config` (
  `id` bigint UNSIGNED NOT NULL,
  `show_userPhoto` tinyint(1) NOT NULL,
  `show_userName` tinyint(1) NOT NULL,
  `show_top_headerMenssage` tinyint(1) NOT NULL,
  `top_headerMenssage` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `show_headerMenssage` tinyint(1) NOT NULL,
  `headerMenssage` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `default_image_post` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `default_profile_image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `jobs`
--

CREATE TABLE `jobs` (
  `id` bigint UNSIGNED NOT NULL,
  `queue` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `attempts` tinyint UNSIGNED NOT NULL,
  `reserved_at` int UNSIGNED DEFAULT NULL,
  `available_at` int UNSIGNED NOT NULL,
  `created_at` int UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `job_batches`
--

CREATE TABLE `job_batches` (
  `id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `total_jobs` int NOT NULL,
  `pending_jobs` int NOT NULL,
  `failed_jobs` int NOT NULL,
  `failed_job_ids` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `options` mediumtext COLLATE utf8mb4_unicode_ci,
  `cancelled_at` int DEFAULT NULL,
  `created_at` int NOT NULL,
  `finished_at` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `migrations`
--

CREATE TABLE `migrations` (
  `id` int UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '0001_01_01_000000_create_users_table', 1),
(2, '0001_01_01_000001_create_cache_table', 1),
(3, '0001_01_01_000002_create_jobs_table', 1),
(4, '2024_10_17_115510_add_two_factor_columns_to_users_table', 1),
(5, '2024_10_17_115519_create_personal_access_tokens_table', 1),
(6, '2024_10_17_125008_create_categorias_table', 1),
(7, '2024_10_17_130032_create_posts_table', 1),
(8, '2024_10_17_130633_general_config_table', 1),
(9, '2024_10_17_193524_category_post_table', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `password_reset_tokens`
--

CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `posts`
--

CREATE TABLE `posts` (
  `id` bigint UNSIGNED NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `excerpt` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint UNSIGNED NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'default_image.png',
  `is_published` tinyint(1) NOT NULL DEFAULT '1',
  `publico` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `posts`
--

INSERT INTO `posts` (`id`, `title`, `content`, `excerpt`, `user_id`, `image`, `is_published`, `publico`, `created_at`, `updated_at`) VALUES
(1, 'Para crear un CRUD completo en Laravel', '<p>Para crear un CRUD completo en Laravel para manejar <strong>usuarios</strong>, <strong>posts</strong>, y <strong>categor&iacute;as</strong>, donde cada <strong>post</strong> pertenece a un solo <strong>usuario</strong>, pero puede tener varias <strong>categor&iacute;as</strong>, y los <strong>usuarios</strong> pueden crear m&uacute;ltiples <strong>posts</strong>, seguimos estos pasos:</p>', 'Para crear un CRUD completo en LaravelPara crear un CRUD completo en Laravel', 4, '1729541404-aprotestas.jpeg', 0, 1, '2024-10-18 23:13:36', '2024-11-26 13:56:36'),
(2, 'Manuales HTML', '<p>Con estos pasos, has creado un sistema CRUD en Laravel para <strong>usuarios</strong>, <strong>posts</strong>, y <strong>categor&iacute;as</strong>, manejando las relaciones entre ellos. Puedes personalizar y expandirlo seg&uacute;n tus necesidades.</p>', 'Con estos pasos, has creado un sistema CRUD en Laravel', 5, '1729412957-2Echenique.jpg', 1, 0, '2024-10-18 23:28:45', '2024-11-26 13:56:40'),
(3, 'Cosas de la vida', '<div>\n<div dir=\"auto\" data-message-model-slug=\"gpt-4o\" data-message-id=\"06af8044-70ca-46a0-b662-07cb101f681c\" data-message-author-role=\"assistant\">\n<div>\n<div>\n<p>Con estos pasos, has creado un sistema CRUD en Laravel para <strong>usuarios</strong>, <strong>posts</strong>, y <strong>categor&iacute;as</strong>, manejando las relaciones entre ellos. Puedes personalizar y expandirlo seg&uacute;n tus necesidades.</p>\n</div>\n</div>\n</div>\n</div>', 'Con estos pasos, has creado un sistema CRUD en Laravel', 6, '1729413016-aprotestas.jpeg', 1, 1, '2024-10-19 00:16:02', '2024-10-19 00:23:44'),
(4, 'Jugoso por dentro', 'Jugoso por dentro, ligeramente crujiente por fuera y nada grasiento. Los andaluces tienen el secreto para hacer el mejor pescado frito del mundo.', 'Jugoso por dentro, ligeramente crujiente por fuera y nada grasiento.Jugoso por dentro, ligeramente crujiente por fuera y nada grasiento.', 2, '1729424287-bukele.jpg', 1, 1, '2024-10-20 10:20:28', '2024-10-20 10:20:28'),
(5, 'Cafes variados', 'Jugoso por dentro, ligeramente crujiente por fuera y nada grasiento.Jugoso por dentro, ligeramente crujiente por fuera y nada grasiento.', 'Jugoso por dentro, ligeramente crujiente por fuera y nada grasiento.', 11, '1729419669-fiscal.jpg', 1, 1, '2024-10-20 10:21:09', '2024-10-20 10:21:09'),
(6, 'Ni huevo ni pan rallado.', 'Ni huevo ni pan rallado: el sencillo truco de los andaluces para freír el pescado mejor que nadie\nNi huevo ni pan rallado: el sencillo truco de los andaluces para freír el pescado mejor que nadie', 'Ni huevo ni pan rallado: el sencillo truco de los andaluces para freír el pescado mejor que nadie', 1, '1729419744-echenique.jpg', 1, 1, '2024-10-20 10:22:24', '2024-10-20 10:22:24');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `sessions`
--

CREATE TABLE `sessions` (
  `id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint UNSIGNED DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_activity` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `sessions`
--

INSERT INTO `sessions` (`id`, `user_id`, `ip_address`, `user_agent`, `payload`, `last_activity`) VALUES
('02BECGOULAo8LfmOlWkAqSFaXX3oTQLxeGKRn7f3', NULL, '147.182.151.182', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiOUYwQzZ4RXNlMzlYblBaNFdOeFVnQ3pVSzRwdURyQVk0Ukg5MjAwZyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTU6Imh0dHBzOi8vampndi5ldSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1730466423),
('2n2jFdLUV50iY0sz7mzZphLOIwH6YksAZJbYhgl9', NULL, '18.212.136.31', 'Mozilla/5.0 (Linux; Android 8.0.0; SM-A530F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.111 Mobile Safari/537.36', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiaXN3S3JrQUtDZlYyYzV4cUdZV2xqU0dmNnJFVXV5WUhDR1pLcmNWRCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTU6Imh0dHBzOi8vampndi5ldSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1729734135),
('3UbZVOMmH4ZRuUhC1yz5qxEee4e5i406WsmGhXVE', NULL, '34.243.150.162', 'Plesk screenshot bot https://support.plesk.com/hc/en-us/articles/10301006946066', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiczg5eDFtaTdJMGhsamZJZkU4dkpjdmxmeE1hNjRybTU3eXJCc0Q1QiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTU6Imh0dHBzOi8vampndi5ldSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1730392788),
('4tCY2zsN1jP7LN3WxNzMx8NPYMz4a4xcwc258HLb', NULL, '34.205.45.176', '', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiT3g5bTdCd09QU0N1NEhlU1Z1QWxncWQ5RTM3czg0THJrTlFXSFdWNCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTU6Imh0dHBzOi8vampndi5ldSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1729831867),
('5kmVlnwhYdnmEiGQ0628RBGuMwXtzTsuY3qUGE0W', NULL, '2a02:c206:3015:2326::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.114 Safari/537.36 Edg/91.0.864.54', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoidUJFYlQ3Z1VhVnBvcm5FaFZxODV6YnpSOURwRlZ2eGU5d0VveFlDZCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTU6Imh0dHBzOi8vampndi5ldSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1730552435),
('8VeeVWnxAMFg4C50SLFzroMMDbF31N2VzdzFI2Nb', NULL, '2001:bc8:17c0:50f:2247:47ff:fe86:94ec', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.3', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoid1VnUWpjdzRhRDRvb2Q1b0U2bmVUSmlPTU9TTEFyTkQ4NUppaWNxUiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTU6Imh0dHBzOi8vampndi5ldSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1729689312),
('90Fg5y78BaWocJzVWrboiXEdB7Te7pZQa2T165IN', NULL, '151.237.58.22', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36 Edg/130.0.0.0', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiTTJRUWQxSkF4cFphV1pVRjhKNUFEZ3drTW9VMmRKTE5YZHRrbGU3TSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTY6Imh0dHBzOi8va2lyYWguZXUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19', 1729636163),
('9eF3dOXCUHC0O1ARy4foK9IqA8p78XP9ysVTsNJh', NULL, '34.209.91.158', 'Mozilla/5.0 (X11; Linux i686 on x86_64; rv:48.0) Gecko/20100101 Firefox/48.0', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiT3lIV1FXeXRMN25KaExzd0lxV1pnQmlXTllCTVE0Z2xLT3ZTRmxwNiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vampndi5ldS9sb2dpbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1730490921),
('Amm4Zsb8xQu1CQOrqavU5l0noJljoCal9rk9XjLi', NULL, '104.152.52.61', 'curl/7.61.1', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiZ1pyYmhpS2hGWEcwRWdFZFo0Nk1SS2FWWU9mNVBGYXlWR3BjZWIwNiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTU6Imh0dHBzOi8vampndi5ldSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1729745106),
('aoc4B4nUpWmVp6iheEwwZnlLmbtwFDGldE4hSkJL', 11, '192.168.97.6', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36 Edg/130.0.0.0', 'YTo3OntzOjY6Il90b2tlbiI7czo0MDoiZlBFZ3o5dG10M3pSU1JnbDY1TmJuSWlWTHc0UFBPY0ZzY29yc1N2byI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzY6Imh0dHBzOi8vc29tb3NhaWwuZGRldi5zaXRlL3Bvc3QtbGlzdCI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fXM6NTA6ImxvZ2luX3dlYl81OWJhMzZhZGRjMmIyZjk0MDE1ODBmMDE0YzdmNThlYTRlMzA5ODlkIjtpOjExO3M6MjE6InBhc3N3b3JkX2hhc2hfc2FuY3R1bSI7czo2MDoiJDJ5JDEyJDIwS1FYQ3k0ZVBoZG83TGFObnFVYy40WnkuZ0VBV1JOY0dSZG16NmNPQTFvOHguR21JMm9pIjtzOjM6InVybCI7YTowOnt9czo0OiJhdXRoIjthOjE6e3M6MjE6InBhc3N3b3JkX2NvbmZpcm1lZF9hdCI7aToxNzMwNjMzODg2O319', 1730633886),
('AUFmVT7sDzmsCEyQgrJkJFJZfVIi6KuEng7E1X1S', NULL, '18.203.238.121', 'Plesk screenshot bot https://support.plesk.com/hc/en-us/articles/10301006946066', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiNlRCdGtkeFgwdGJnZDlKdlJGOXlZODk2YjIzdUJONFJhdVpxY0tobCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTU6Imh0dHBzOi8vampndi5ldSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1729901659),
('b3txAeXYEc7lWAuXqvKmV3vmtyoRKtv5DwkCbR0r', NULL, '171.244.43.14', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Mobile Safari/537.36', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiUW9Ra29pWFpuSVpkS1Z4YzE5eWlEdlNLNHVjaGE5Y3JhTUJZaWlEZCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTU6Imh0dHBzOi8vampndi5ldSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1729669030),
('bDozE7u6NpX4zftGpg1lWpJiXrUBR62aoX0K6u3F', NULL, '104.166.80.220', 'Mozilla/5.0 (X11; Linux i686; rv:109.0) Gecko/20100101 Firefox/120.0', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiV0NFRDBjSEtTQnpsbTVtU096UFI5RWJqdVY3dk5EQWluZEd0em14USI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTU6Imh0dHBzOi8vampndi5ldSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1730132393),
('BEXYdCukvuUPx0qNAaYPLEmli5BvFHeGYACWbHhi', NULL, '52.169.125.231', '', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiOGFTNWowQWFHclhUaVR3UFJIaFRVTlQyV1g0elFlZ2VSVG1UamhXTyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vampndi5ldS8/ZXJyb3I9NDA0Ijt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==', 1730389553),
('BiXp9uRmPG1of26v4QV32pJb85vhqSsF7hKm0eJU', NULL, '104.253.203.103', 'Mozilla/5.0 (iPhone; CPU iPhone OS 16_1_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.1 Mobile/15E148 Safari/604.1', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiUVlyNVdXQlZMOEcyZzJuYzQyQnVhQ1VMY1pBVG1kNkU3bDBHUkZhbCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTU6Imh0dHBzOi8vampndi5ldSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1729642595),
('bPeFEKgndEpCIo9x7xVhsDRgiajfZUGdqbGgJrjw', NULL, '34.218.230.101', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:52.0) Gecko/20100101 Firefox/52.0', 'YTo0OntzOjY6Il90b2tlbiI7czo0MDoiMlVkdVRDR1gySUNLSjNzYkg3VGdPMFZHeWNYbThaYnlNTWQ5bEs1eCI7czo2OiJzdGF0dXMiO3M6MTY6IlZpZW5kbyBsb3MgcG9zdHMiO3M6NjoiX2ZsYXNoIjthOjI6e3M6MzoibmV3IjthOjA6e31zOjM6Im9sZCI7YToxOntpOjA7czo2OiJzdGF0dXMiO319czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjI6Imh0dHBzOi8vampndi5ldS9zaG93LzMiO319', 1730490204),
('cfWFGHeCRAIawbDceiPqD13HkSNjg8xquzbYZel9', NULL, '109.202.99.36', 'Go-http-client/1.1', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiS0RDWmZBbVFjQWQ2VXl1MkN6dVUyTFBLd2ZrU1dVc2lmQ2NycjVZRiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTU6Imh0dHBzOi8vampndi5ldSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1729644498),
('cKQGISBnjHqQcVhKIfEmRLckAtD4fhq4PLYqPJHy', NULL, '20.115.49.134', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiRzQweFRXR2FkWTZXbUN2RmV2djVXWmhnRVc3MDVld0gyV1I4eHhVeSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTU6Imh0dHBzOi8vampndi5ldSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1730590237),
('dN8SMDBHn8ePTPeR9qSPsnYI52hVZgxsSkPa5SQQ', NULL, '109.235.74.132', 'python-requests/2.31.0', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiMHZmV2RMTzA4UFFsdVE0V2FxZWVVOFQ2U1dMQ0h1WjV6d1h4YUtERiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTU6Imh0dHBzOi8vampndi5ldSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1730027297),
('DWd4M9gS6JAhFZEhil8QgZg4gkH4MvvIZoScT39z', NULL, '54.170.116.160', 'Mozilla/5.0 (compatible; NetcraftSurveyAgent/1.0; +info@netcraft.com)', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiNk40ZWxKS2xOdDlreHBuWXJCZ3JMQlFqNHAybFpzSUZNUEFSckxlZSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTU6Imh0dHBzOi8vampndi5ldSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1730501122),
('dZHb5mIlqDzYSIS1qc74m8j9lSLSOH4N1oxA108r', NULL, '209.97.189.226', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiZlJGQ01zdVYyNFdoUDRzajJQV3RSYzgyNkVoWVNpdUFSYVZPU2RKWSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTU6Imh0dHBzOi8vampndi5ldSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1730031920),
('F2C047eQCiYWwrtQtQ1SNoOJ3WuTYZUoJzmj50gE', NULL, '171.244.43.14', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Mobile Safari/537.36', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiQTVFSXQ5dkdFUFlsaDBmVnVYZWdhOEptdFJUUXhBbUdtNzVLaTExcSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTU6Imh0dHBzOi8vampndi5ldSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1729640275),
('GFb6nnluEdl7lFidi2XCeLaBKAp3Ld9JXqMIEVmI', NULL, '178.62.24.30', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiREZTZDRvVGszdUhMTFFFSzd3WEFCUDZCUlhJUmtEc0xibzFuTVZrRyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTU6Imh0dHBzOi8vampndi5ldSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1729686410),
('GFSEkMvkzbsmNmTGzj5Q9uJgIAoDIp0ElN9IrdpX', NULL, '34.230.15.100', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiaVVBcjFLck5kNDJNZHJWSUlQZUkzZkdPYVB6MnNucGtrenZkR3VNRyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTU6Imh0dHBzOi8vampndi5ldSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1730058500),
('GixDJWEsgJ6hI2maTKYaezWPJ3WRgRrUAVUtA0B6', NULL, '35.89.28.7', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiVk05V3ZPMGNPdnBYbDVzdDJHbEVWU3U1WWpRY2ZMYnlsWHBUUWplNCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vampndi5ldS9sb2dpbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1730490629),
('GKv8ajBnj9Pi9TLplyKeIW1a3ba9Js2EHtCEUrzt', NULL, '87.236.176.11', 'Mozilla/5.0 (compatible; InternetMeasurement/1.0; +https://internet-measurement.com/)', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiS0RIc3o0MmFXdlpZTkxSbGtGUHhTNmUyUDFTN1hiQ0MwamF6VjhqQSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTU6Imh0dHBzOi8vampndi5ldSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1729740574),
('gNuQ29hVjyueFzMPY8m70E1DbuUDujPHzFLftWFS', NULL, '35.92.95.46', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/53.0.2785.90 Safari/537.36 Vivaldi/1.4.589.11', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiNjRLeGVpb1UxU2VROEpja1dNQkVCTGdQT0E5RFdGQ2o3UTcyRWF5USI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTU6Imh0dHBzOi8vampndi5ldSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1729889786),
('gT35D4lVCLtbeLkuJYsga4K9A05hQ4YvNf08VDfW', NULL, '87.236.176.69', 'Mozilla/5.0 (compatible; InternetMeasurement/1.0; +https://internet-measurement.com/)', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiSHlmVXhyQU45YXRSUWlRcUZ1bmNKeDViOHBLaTQyUEU3TmpZWlZQRSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTU6Imh0dHBzOi8vampndi5ldSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1730241932),
('h5be8YxoOOMWyxl5rCrOAOp15fVj0OL7Yo6wVkap', NULL, '2001:bc8:1201:61f:569f:35ff:fe15:bc90', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.3', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiY09pSWVWRHhlYUpYaGxDOUMwSmlhWDBvcDZoaEM4dEFIZUFMMjlLayI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTU6Imh0dHBzOi8vampndi5ldSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1729732361),
('hGSrYk7FK6MN25zuDcclJiyd36NHYi4WE1aLJiuC', NULL, '3.140.208.146', 'Mozilla/5.0 (X11; U; Linux arm7tdmi; rv:1.8.1.11) Gecko/20071130 Minimo/0.025', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiZzRDWmhqNUR3RGJMdjBXSTl4UmVJb0hIeUh3OGd0eUxqdTl4Yk1IaCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTU6Imh0dHBzOi8vampndi5ldSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1730369991),
('HsxFHTY4tagyImg6g9bCgkFt7xBthaTGXfalosR6', NULL, '152.32.162.60', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_7_0) AppleWebKit/535.11 (KHTML, like Gecko) Chrome/17.0.963.56 Safari/535.11', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiV3ZIcTJtUU9uejg5VXhzcVJJdThnbk1MUndObkFuTjlrb1c4TVMwbSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTU6Imh0dHBzOi8vampndi5ldSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1730259239),
('hsxPzpPUfIVvWKELoW9wrEbeLLEysPL2FyHtO4f3', NULL, '34.205.45.176', '', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiZmN0RzZjRzlxWU5EVDVjZktoTzQ4bW55VTVuVkRqdWNjZGpaZHBEMCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTU6Imh0dHBzOi8vampndi5ldSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1729831868),
('htLDAKOeUvwouBKQxTthhjap5YcmFWzqbVBjqLbI', NULL, '195.211.77.140', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36', 'YToyOntzOjY6Il90b2tlbiI7czo0MDoiazVqaXVzMDlRTHhNMkdJYzVZWVUzSjhoZ2NxaXZzTWdUZDgwR0RGRiI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==', 1729642290),
('HXzFNqAegLcGAQEdZxIkCxGTJrND18wasfpBuf1z', NULL, '47.128.17.161', 'Mozilla/5.0 (Linux; Android 5.0) AppleWebKit/537.36 (KHTML, like Gecko) Mobile Safari/537.36 (compatible; Bytespider; spider-feedback@bytedance.com)', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiN2hEU2o2OWY0TEJMZ0RrTzVGdm1nSmlnd2V4VmNXV0I4NTZFY0RNYSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTU6Imh0dHBzOi8vampndi5ldSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1729835739),
('IlhAyH0lMKW1W4BdzdDR1XNHwA4HmBm8RYru5LP9', NULL, '3.250.89.29', 'Plesk screenshot bot https://support.plesk.com/hc/en-us/articles/10301006946066', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoienRKbjU3ZlJPUlAwRDg3TWF4ZFpGb2hKdkpoYnRwd0JFWUxmb3pLZyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTU6Imh0dHBzOi8vampndi5ldSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1730589070),
('InF66mXOCOIStkI9r7Az0J4CLc8snVpwhUMt5PFd', NULL, '52.236.37.55', '', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiaUlSdkc3R09yMXZoaExTajVHRnpQbVE4bjkxTkV4eGUzNGZPN1hpTiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vampndi5ldS8/ZXJyb3I9NDA0Ijt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==', 1730292619),
('isso9F0uChGPJM1k8zUC8TOeV5ltgDWv3aN6ykBR', NULL, '8.41.221.60', 'Mozilla/5.0 Firefox/33.0', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiRmZmQlFOS2hSMng1dmxBY3A2cDlYMHppN3AxRHFaVTBHTlBzY3VaUSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTU6Imh0dHBzOi8vampndi5ldSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1730510624),
('iZfV3uzmDq18d1UZYVyfL1kXBUEUDmzGmw8b4pG8', NULL, '34.215.28.236', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:51.0) Gecko/20100101 Firefox/51.0', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiczZ2d3VrNDFQTHc2QmdsZkJoblNta2dlcHExQnRYcUt0TEpKek5RbSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjA6Imh0dHBzOi8vampndi5ldS9ob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==', 1730490879),
('j1O3jC4eMV14632dehFDFkKOCSbjtZH8fnsLxeGZ', NULL, '176.126.103.21', 'python-requests/2.32.3', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiUjdGbzc1UXp3amV2UEVQMTBWOThhUjhqVDZwejkzaHJ5TGphUzJRSSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTU6Imh0dHBzOi8vampndi5ldSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1730475017),
('jxFljNJEIcePQSRg636eP5agKu1aNFjBlEjzTgcT', NULL, '52.37.103.159', 'Mozilla/5.0 (X11; Linux i686; rv:48.0) Gecko/20100101 Firefox/48.0', 'YTo0OntzOjY6Il90b2tlbiI7czo0MDoibUVIVnVPNjNqY210YVBNTUNjRmtnT1poOHBUMFlmMEhQakw2ZU9VeiI7czo2OiJzdGF0dXMiO3M6MTY6IlZpZW5kbyBsb3MgcG9zdHMiO3M6NjoiX2ZsYXNoIjthOjI6e3M6MzoibmV3IjthOjA6e31zOjM6Im9sZCI7YToxOntpOjA7czo2OiJzdGF0dXMiO319czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjI6Imh0dHBzOi8vampndi5ldS9zaG93LzQiO319', 1730491019),
('KsD2ePmZKbk9t3jTv7WCRp8ZhZEpDrH30DnYc9Hb', NULL, '80.248.227.19', 'Mozilla/5.0 (iPhone; CPU iPhone OS 17_3_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.3.1 Mobile/15E148 Safari/604', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoidE12clhZaWY0NjE2TE5NNHZEd0VycWFqaTRrV05wcVRtU21ORW1RZyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTU6Imh0dHBzOi8vampndi5ldSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1730397396),
('kx18UxDHDlGH48lIFWwyZZbnVbwvcNZrQ9YxLfbr', NULL, '2001:bc8:1201:61f:569f:35ff:fe15:bc90', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.3', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiejd1QUZwTGZ6eUNCekRWYjVWM05mamxOcGNmV1JyTUZCN1VSNTFXdiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTU6Imh0dHBzOi8vampndi5ldSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1729732357),
('KxmdFxrhuSQ8UzHS0522FZ9GHSeAPHylkLEg8CPv', NULL, '104.166.80.213', 'Mozilla/5.0 (X11; Linux i686; rv:109.0) Gecko/20100101 Firefox/120.0', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiODFxS1ZQZzcwUVh0RWFDUW1WSUdNNEpxd1M1QXpMRnJ2QlRiMlZEYyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTU6Imh0dHBzOi8vampndi5ldSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1730477436),
('LAIIuxwdb17XcYUVp0gEuYF336OzPxlvAFlDB5jy', NULL, '45.137.198.155', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/53.0.2785.21 Safari/537.36 MMS/1.0.2531.0', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoibW1ZemZVVWdaRUc5cnRRYnNlZXJCZzlwQXN6QmF3S0RubVdQSGY1dCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTU6Imh0dHBzOi8vampndi5ldSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1729733074),
('m4PUYd7DdoJQfyggjzix4qgCGQ3ETliWs4wkffKE', NULL, '2a05:d018:1d9d:e702:71c4:e8b2:3470:c60a', 'Pandalytics/2.0 (https://domainsbot.com/pandalytics/)', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiNUJIRUNBaHBtWm5UelladldxbHFtdEM1SXVJRGpwY2RIV09IQjRZayI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTU6Imh0dHBzOi8vampndi5ldSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1730054121),
('mf7oLonVSQPq7O1Vfp52gkTflcEfkTN1IMfRu2QD', NULL, '87.236.176.102', 'Mozilla/5.0 (compatible; InternetMeasurement/1.0; +https://internet-measurement.com/)', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiakZ6cnBBQmxmVFl6OHNuT1EzVHZaN2dYMjBWa0VZNWkwNEJhV1lBUSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTU6Imh0dHBzOi8vampndi5ldSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1729711024),
('mLU2WgaKTpcCs2Vu00r99kykfQC94Bkk7D7RbAkQ', NULL, '205.210.31.25', '', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiN0xqVVdUdnl4TUtEUVNkeWdQMlhNVEJsa052OG5yWnBSYVRoVHg1NiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTU6Imh0dHBzOi8vampndi5ldSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1730549351),
('MmT48awQnFQBI9w0RZeUVN7ZHXX7rqYdZZ7KfEXo', NULL, '34.217.207.192', 'Mozilla/5.0 (Macintosh; PPC Mac OS X 10.9; rv:48.0) Gecko/20100101 Firefox/48.0', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiMW83WEJXV2R0dWlob1pjakpLaUZPelVTd0ZDNUMwQU16SHhPUlZUWiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTU6Imh0dHBzOi8vampndi5ldSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1730490827),
('MRnlPRXyMeryZJpXYqDZEweKKCElC7a01YjvEAKc', NULL, '89.23.108.137', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/14.1.2 Safari/605.1.15', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoicmZrR3VWUU0xUUIzclZybEhxQzQwT2I5MXpNT2ZQdk0xN0pYT0laUiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTU6Imh0dHBzOi8vampndi5ldSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1730342834),
('mZDofv9Kh3DLnQsCjYjsYjJXWCIamd0dCx1jaixr', NULL, '5.133.192.136', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiN1BBemFJOVIzZkVoS05IdUlJWWdzTkljdkM1bWcwOVpjNG5tSzVnRCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTU6Imh0dHBzOi8vampndi5ldSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1730136431),
('N92AnvpXgJG2NXTfSXfP8mcBSO4BxruimR0ZaEFr', NULL, '195.211.77.142', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiUjhRNWc3MURaOU1POHV4cDVJaEdsdERJdUJJMVg1cU1RWFZhQzBnVCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTU6Imh0dHBzOi8vampndi5ldSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1729642300),
('NcNmeWPSGstZsRNDQYX2MBJNIV59JppyrDQmeIzg', NULL, '209.127.109.183', 'Apache-HttpClient/5.1.4 (Java/11.0.18)', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiWVlaMFExWnlodjZEMTVnYVJzdnl6TXhkVGNqWU9scDhRU2wzS25ldiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTU6Imh0dHBzOi8vampndi5ldSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1729758422),
('nI6ul6SJMSPHWVApR0ob4BJvr2NglW62Nw5y4UvH', NULL, '104.166.80.194', 'Mozilla/5.0 (X11; Linux i686; rv:109.0) Gecko/20100101 Firefox/120.0', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiZlJ2SVZFeWRSTTlWZUFBTFNZMGVsZE45NWJnOXQ1ZTJMUW9kcnhpdCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTU6Imh0dHBzOi8vampndi5ldSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1730043196),
('nNz9TMTt0Ldqxg56YDi7z86Awn01BpHKTLRovHQq', NULL, '142.93.198.116', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoidDhNWmlzcUdScHBPSHVQQk9rV2xheG9YcUN0TFB6N1llRmtVeGd0biI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTU6Imh0dHBzOi8vampndi5ldSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1730379966),
('nOfsILyLM4ZCUq3waBnXgfOvaIuJlLHajO0afDdt', NULL, '104.166.80.68', 'Mozilla/5.0 (X11; Linux i686; rv:109.0) Gecko/20100101 Firefox/120.0', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoid3QzVTlzdXV2ZU9LdUpKcjMyU3QzNXZxQ3dEUUtSVXkxWGZpY0p5dCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTU6Imh0dHBzOi8vampndi5ldSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1729784105),
('NoIcwpyXLPzDoMayNriMdi3Nouy1UqU0PDY0cxay', NULL, '45.137.198.155', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.110 Safari/537.36', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiMzdLT2RtcWVBcXltdVFBb3ZTZkd2NERIVnVMWlJpRkVSREVHRzdQViI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTU6Imh0dHBzOi8vampndi5ldSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1729733994),
('OZd2FMeKk6QLtitRDQG9aSI1rVifeUQkUDWktyEo', NULL, '152.32.162.60', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_7_0) AppleWebKit/535.11 (KHTML, like Gecko) Chrome/17.0.963.56 Safari/535.11', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiMk5teHAxY28xbG9ZTFJsVEJBaTlGWFdhNDRtb1dsZ1doQjRmakFTbCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTU6Imh0dHBzOi8vampndi5ldSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1730259407),
('P1eh3MsB3w1K3mvcirx0SaLpsQdWUIe3jmzWTw41', NULL, '45.149.241.21', 'Mozilla/5.0 (iPhone; U; CPU iPhone OS 2_0 like Mac OS X; en-us) AppleWebKit/525.18.1 (KHTML, like Gecko) Version/3.1.1 Mobile/5A347 Safari/525.200', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiZEN3Q0lQRW82T1hQbExJbnNGM0Z5ZGprdmJSUDdwaXJWRDQ2aXBNeiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTU6Imh0dHBzOi8vampndi5ldSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1730616118),
('P4bsU19HZ8eMTUsKNWMy7RFfeWQn0O2bisXkbmd9', NULL, '95.164.157.3', 'Apache-HttpClient/5.1.4 (Java/11.0.18)', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiZVZwYjZzM09hSGNDMGViemg3TTFTTHNURHpMd0puV1p6SU1wVkZJVCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTU6Imh0dHBzOi8vampndi5ldSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1729641555),
('po00FlsTyoDd7LkDkX4z1EywPtjR5gTd9w4TcCTf', NULL, '52.138.201.151', '', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoic210M3lNMG4zWlZnZ3RUUFhKZ2RUYUNCb0d6ZkRYcEE3OFh1ZGxubyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vampndi5ldS8/ZXJyb3I9NDA0Ijt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==', 1730600170),
('PuAtAUgSgJPLZZ0ZmChD8AB8f1cNYEzyoTpIHq1L', NULL, '63.33.50.112', 'Plesk screenshot bot https://support.plesk.com/hc/en-us/articles/10301006946066', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoieTR2ckZKb2FiUWFDbjBHTGRIcWdBbTQxOUxvcHJPeXdjTjdINFlQWiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTU6Imh0dHBzOi8vampndi5ldSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1729727094),
('q0FgNR6dpywmePef6bkzleQPeQde7wJmKDz7ShrK', NULL, '34.215.101.215', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:47.0) Gecko/20100101 Firefox/47.0', 'YTo0OntzOjY6Il90b2tlbiI7czo0MDoiYWFodDBPZERxM2tURlFydjBzQlB2eUVsRk5LcDhNZzNvbUU4ZWJCUyI7czo2OiJzdGF0dXMiO3M6MTY6IlZpZW5kbyBsb3MgcG9zdHMiO3M6NjoiX2ZsYXNoIjthOjI6e3M6MzoibmV3IjthOjA6e31zOjM6Im9sZCI7YToxOntpOjA7czo2OiJzdGF0dXMiO319czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjI6Imh0dHBzOi8vampndi5ldS9zaG93LzYiO319', 1730490947),
('qCqFPb2VHHAboNInuWSTKTQyvj0aYPbi96xRZAJf', NULL, '52.24.130.242', 'Mozilla/5.0 (X11; Linux i686; rv:54.0) Gecko/20100101 Firefox/54.0', 'YTo0OntzOjY6Il90b2tlbiI7czo0MDoibVlUZnUyczVweHhwTGJqTENreTdyZUpmUFZFbXhhQXNvclJrY1RGTCI7czo2OiJzdGF0dXMiO3M6MTY6IlZpZW5kbyBsb3MgcG9zdHMiO3M6NjoiX2ZsYXNoIjthOjI6e3M6MzoibmV3IjthOjA6e31zOjM6Im9sZCI7YToxOntpOjA7czo2OiJzdGF0dXMiO319czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjI6Imh0dHBzOi8vampndi5ldS9zaG93LzEiO319', 1730490785),
('QrBzMEQjfGDUE07V2Oe2AsoBp9qbn35Y7hhirwPU', NULL, '2a01:4f8:10a:2d6::2', 'Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.5993.80 Mobile Safari/537.36', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoia2pyRWp4MklselBTN2hHbVhpRFExV1NjMTVtUVd1d245ckJ4TEVJUyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTU6Imh0dHBzOi8vampndi5ldSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1729642662),
('qWDQlU8hqQX2X293VKRdQFfZyPyw7RFJxCOGJg5Q', NULL, '34.222.157.161', 'Mozilla/5.0 (X11; Linux i686; rv:46.0) Gecko/20100101 Firefox/46.0', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoieElrZWc1NTFjS21TdWJoSW5zTlNHR3lhMnIwUFRGTHRNazBoTVhPZiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjQ6Imh0dHBzOi8vampndi5ldS9yZWdpc3RlciI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1730490749),
('recToJ3aS1WiUnlyjI2YY16zl0MElcKl6ZJlDSRt', NULL, '35.90.12.72', 'Mozilla/5.0 (X11; Linux x86_64; rv:48.0) Gecko/20100101 Firefox/48.0', 'YTo0OntzOjY6Il90b2tlbiI7czo0MDoiekFPVmtveWpST2VpMUJqMFl0ems4c3Eyd00zbVNsYk1kUWtBbVN1RyI7czo2OiJzdGF0dXMiO3M6MTY6IlZpZW5kbyBsb3MgcG9zdHMiO3M6NjoiX2ZsYXNoIjthOjI6e3M6MzoibmV3IjthOjA6e31zOjM6Im9sZCI7YToxOntpOjA7czo2OiJzdGF0dXMiO319czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjI6Imh0dHBzOi8vampndi5ldS9zaG93LzIiO319', 1730490596),
('ReLdR963aGoKeR6aWoGYMmA8pVrlcc0v2D6XOOhm', NULL, '2001:bc8:701:1e:1618:77ff:fe4d:4fc9', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.3', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiR2pZRXFlczhKRzJrY1pLWTlIZ1I0TUJJczFCU1JrTlh2dXgwanNidCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTU6Imh0dHBzOi8vampndi5ldSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1729732366),
('rr7n0ATctxdZvGm5r4u3YGzNBll2TE1upeWjnqb2', NULL, '199.244.88.225', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiSFVqUFhhSVFwdnRkTE1KOU92V0pzOFRZdDJMNUtNclhFVlBqWDBSNiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTU6Imh0dHBzOi8vampndi5ldSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1729807627),
('rXYOHbBCVRLcES9OeGuU1ATf5lbN44lysyBsp1Sz', NULL, '52.178.156.184', '', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiM1ZnQ2dhTWpTS2VLV1pIdjVxWnBkcThsT3JQVkp0VGZTRzJpa2M2NCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vampndi5ldS8/ZXJyb3I9NDA0Ijt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==', 1730349454),
('rZtB7BNSiqOVjOcXoGyp658G7Hl0hJ4aIOq9lhul', NULL, '104.252.186.54', 'Mozilla/5.0 (iPhone; CPU iPhone OS 16_1_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.1 Mobile/15E148 Safari/604.1', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiRGZrZDRZN0RodGxxU0tKbW1RN3llaGg2T2duZzY3akd6VmwyMXNFdyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTU6Imh0dHBzOi8vampndi5ldSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1729642573),
('t8vOfI7C1T62uXMrEjFsROwPvJbIKHmrATwE11SF', NULL, '8.41.221.60', 'Mozilla/5.0 Firefox/33.0', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoidm9aTEQybnFQTnhhVEZyWGttU1BOOUhRSWs4QUlRbkVYRHVTZlZ0NSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTU6Imh0dHBzOi8vampndi5ldSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1730510628),
('tEzXN88KbNCnjeB6R9xH6eIToU8sp8IcrkvPNeh2', NULL, '104.166.80.87', 'Mozilla/5.0 (X11; Linux i686; rv:109.0) Gecko/20100101 Firefox/120.0', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiS3VmTWNZWFg2NU9BTkpvQ3hvb3ZnUFE2bG1vVkFMY0lkRUgwVGdSZCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTU6Imh0dHBzOi8vampndi5ldSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1729956572),
('TK1wvSOj9isEDTYFU0dK55X6H8KcPE7FCO2ljMnh', NULL, '154.28.229.98', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Safari/537.36', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiMmdVbWY3c1E3WVR0N0czclVuNzBCNUlaWk9KN0RYUXE3ZFoyQ1Q4WCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTU6Imh0dHBzOi8vampndi5ldSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1729685700),
('ttKc5hvquyg3MDXqBxOyqaFi5BHvxciV5Ja7uD30', 11, '151.237.58.22', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36 Edg/130.0.0.0', 'YTo3OntzOjY6Il90b2tlbiI7czo0MDoiOUg2dFRuWWRSMklYZHpNcXo5SEVlZDhEQ3MzYmt0VHhMOFRQUVlOOSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjU6Imh0dHBzOi8vampndi5ldS9wb3N0LWxpc3QiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX1zOjUwOiJsb2dpbl93ZWJfNTliYTM2YWRkYzJiMmY5NDAxNTgwZjAxNGM3ZjU4ZWE0ZTMwOTg5ZCI7aToxMTtzOjIxOiJwYXNzd29yZF9oYXNoX3NhbmN0dW0iO3M6NjA6IiQyeSQxMiQyMEtRWEN5NGVQaGRvN0xhTm5xVWMuNFp5LmdFQVdSTmNHUmRtejZjT0Exbzh4LkdtSTJvaSI7czozOiJ1cmwiO2E6MDp7fXM6NDoiYXV0aCI7YToxOntzOjIxOiJwYXNzd29yZF9jb25maXJtZWRfYXQiO2k6MTczMDU5MDI0ODt9fQ==', 1730590433),
('TvNqGoCMuMz17HIr1aexFUFKaPAd7YKgurotVU8M', NULL, '2602:80d:1000::55', 'Mozilla/5.0 (compatible; CensysInspect/1.1; +https://about.censys.io/)', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiZ2NHYVdsNWpjV2JVMjN5enBFVlNlZzNCbEh3ZlA4VjdobU1TcGJTWiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTU6Imh0dHBzOi8vampndi5ldSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1729638850),
('ugdrhBMZvY9wNOSl97koNYvhcdlt3ChC03b4YHfT', NULL, '185.6.9.148', 'Mozilla/5.0 (Android 14; Mobile; rv:123.0) Gecko/123.0 Firefox/123', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiYzNaN3ZKUnI2S1cwd0VxeGI3bXdQMEt3dkhsellMY0VYQVFkUTNQYiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTU6Imh0dHBzOi8vampndi5ldSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1729876162),
('uK1m3O18cImz7cMB9vzzTtDrPImNx0cI6xR5XPZR', NULL, '152.32.162.60', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36 Edg/120.0.0.0', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiRkZJUDRQcUhPYkFTcWJtc3ZGSGJtMUsyVUlvcWhXNmo2VG52YjlIbSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTU6Imh0dHBzOi8vampndi5ldSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1730259218),
('umDXkLnV01hvTAXq6Pb1bJ7VSLvUY5GQ74m3tvBt', NULL, '132.255.133.39', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/107.0.0.0 Safari/537.36', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiWVU4UFJnTk5Pb2ttNEFJMk05REV5OXJ3SWhoaVlzN1VTeDVUZEdiYyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTU6Imh0dHBzOi8vampndi5ldSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1729641557),
('uOZCmSgcPj867pNOchh3L4ZjeRs5BY6ASioC8SnL', NULL, '154.28.229.251', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Safari/537.36', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiVkc0cE44T054ZEhIZ1BDbXMyZzFlWEtBSEV1YVZFUVdWc1poRXV5TyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTU6Imh0dHBzOi8vampndi5ldSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1729640151),
('URB4A36QImHyFj70HyArDnTdeMtuo6Dj4ZLAhPMO', NULL, '2001:bc8:701:1e:1618:77ff:fe4d:4fc9', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.3', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoieFV1RzhqZ0d5cDY0b2xweEplSmVVQWZxTWp6MElwbHZkRFhLVXo0WiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTU6Imh0dHBzOi8vampndi5ldSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1729732369),
('Us8Bskmw3JHFlpuE8BAN0L1uHvbPzmzIBWBMMs5I', NULL, '3.250.161.133', 'Plesk screenshot bot https://support.plesk.com/hc/en-us/articles/10301006946066', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiMTlWNmVJRDlZd1NGSFBwQjBTcG5zMzFONlphOU9YZTdmUGZoNzVvbiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTU6Imh0dHBzOi8vampndi5ldSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1730631651),
('UXTgaveoarmJEhFXtOCLmfHzHOTbGPLbQ1BSED3w', NULL, '38.154.198.253', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/107.0.0.0 Safari/537.36', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiRnBQeE9EVzJSUzBGR0FHMlpJMm9ua3g0ZXdTeURKcFpQNWQzVWRyciI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTU6Imh0dHBzOi8vampndi5ldSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1729758427),
('vG0pfLC8TgZ9D5uIjEGUiLxSsf8UtQ1iMcYtmPla', NULL, '138.197.121.254', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoia01RMHNtcGVUVnBYZTRIMW15V3F5T2lsYmE4ckNqUWRrWXBlazROWSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTU6Imh0dHBzOi8vampndi5ldSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1729865124),
('VtLBHbncwK4dlWlqC3ceIcaBJcuX16lvfZq6ujf7', NULL, '88.16.60.218', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36 Edg/130.0.0.0', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiTndyMXk3aDJLVmZkUlFDakFLc1dhVUhoekdyc3JsMzBkdWRRb0ZObCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTU6Imh0dHBzOi8vampndi5ldSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1730633676),
('VtvaOiUhuzAp8xOGQmfn6RcB4UfWvkiCc73BuCXz', NULL, '87.236.176.221', 'Mozilla/5.0 (compatible; InternetMeasurement/1.0; +https://internet-measurement.com/)', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiWmhod0hnTTJma0g5cWFBTUZ2T2VNd0tqWkN4RXk0Nk1wcHRZS0pzTiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTU6Imh0dHBzOi8vampndi5ldSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1730185846),
('VZhDZyW8luGLQkiELFgExf028S5U6Y5dTnrKnl1K', NULL, '183.129.153.157', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.108 Safari/537.36', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiRVFMamRGdGNLVWlRWlVXYVJESUduSWljeEhPUmpXVkVJVVF4SU5tdyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTU6Imh0dHBzOi8vampndi5ldSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1729818173),
('WUBkeEEtmZERILj6d1VCKBmIiwHyx1nOXe8MB0z2', NULL, '104.166.80.15', 'Mozilla/5.0 (X11; Linux i686; rv:109.0) Gecko/20100101 Firefox/120.0', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoidGJJRzQ1WFNzYndPWVBIalJjNGxESmhiN01ZZVdDSGNCY3B2d3JiYyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTU6Imh0dHBzOi8vampndi5ldSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1729869516),
('x0yDGeGR8oEXoI81UIEeM8DTjPf0XZVJw86MJ23w', NULL, '134.122.74.224', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoibXhhbDNhSGFvdUFxU3RSMUVSR005NklocUNaTGtCTEpFNWFScUVORiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTU6Imh0dHBzOi8vampndi5ldSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1730550837),
('x81cvVeJyt24IxKFl8zbxTGx10Qz94TFHB0mbYfn', NULL, '54.244.193.109', 'Mozilla/5.0 (X11; Linux x86_64; rv:49.0) Gecko/20100101 Firefox/49.0', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiZEtuWFB5bzVtaXQyenN2cHl5UXlCS1IyYWNMNmJZUFNuNVNxdlAzdSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTU6Imh0dHBzOi8vampndi5ldSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1730409018),
('XlVtakbld6Hsh4sOpWEuDJzfVRe5xSs7i0f1japK', NULL, '45.200.148.16', 'Mozilla/5.0 (Linux; U; Android 1.5; en-us; SPH-M900 Build/CUPCAKE) AppleWebKit/528.5  (KHTML, like Gecko) Version/3.1.2 Mobile Safari/525.20.1', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiek9jVWZwcTlldzdWUU00OVh4blhnbnhwS1BEU1lsanhjSUM3OFJ6UiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTU6Imh0dHBzOi8vampndi5ldSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1730271827),
('xnEH6ixSPikJxZMb3lGMcu4PGrlMATw9kTc22ZCS', NULL, '192.168.97.1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36 Edg/131.0.0.0', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiQ2h3SjdORm5ZOXgwMGJkVkNMUXlxaHdrSFNSRXB3OTA2bWRrQllHOSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzU6Imh0dHBzOi8vd2ViLmRkZXYtc29tb3NhaWwub3JiLmxvY2FsIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==', 1732454222),
('xPFIz47uEpf1SdYVnJjUgmGsuVaZb1gtbYvwRvgS', NULL, '104.152.52.64', 'curl/7.61.1', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoieFN6bEF5d3N2ZHZwc2pEem04M1paMDlSRzVkZ0lvZ3RRcUEyYVBSUCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTU6Imh0dHBzOi8vampndi5ldSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1730390745),
('y6ZPL6cWXT7G1lli8lRDFl9PbikFgbeYQzgeRLph', NULL, '192.168.97.6', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36 Edg/131.0.0.0', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiWVY1WnBCYXVNajlSeXJ2ckY2TnhvcXo5S2VwQ1gxMUpxaUltU0pxbiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vc29tb3NhaWwuZGRldi5zaXRlIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==', 1732457007),
('ymWmLgDUMyRF2G0fxfrpVEqhEnB0uW0FzR8mpCjR', NULL, '152.32.162.60', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_7_0) AppleWebKit/535.11 (KHTML, like Gecko) Chrome/17.0.963.56 Safari/535.11', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiT3BDRHB5dUtCaGd1cE5ETFFnMU5ac0ZCckRXTFBRek5rckYybjRxbSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTU6Imh0dHBzOi8vampndi5ldSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1730259408),
('zBfEw0YthHSckE9GZFVJu19pDJUegVraidBhi9TU', NULL, '34.205.45.176', '', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiMFZzTWlidTFIN0VjRHVWV1lLMERQYnBBRU5OalJjbWVIVklvcVJ0aCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTU6Imh0dHBzOi8vampndi5ldSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1729831870),
('zrn6cwDbTZ77dHlsqn8KxEjeep9jPdRcPqFalfp3', NULL, '104.166.80.34', 'Mozilla/5.0 (X11; Linux i686; rv:109.0) Gecko/20100101 Firefox/120.0', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiV3JhYzBXajJNeFpSZkhBaUdRczU1UTZWUEtnN09ZajROcmk0b3NYdiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTU6Imh0dHBzOi8vampndi5ldSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1729695636),
('ZVYMdTv9jVTa0ZYmfSv0objROIRXMvXIMSDcVC7q', NULL, '2001:4ba0:cafe:b2c::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.114 Safari/537.36 Edg/91.0.864.54', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiVHdtZjZMU1pTNDVRTE9YNTQ5THZxbHNYU3ZKbldGaFNJNUd6ekVhMSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTU6Imh0dHBzOi8vampndi5ldSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1730001827),
('zw08ezrg7KhIvpM4pOdxEArfMiO7DxbQd0SWCNTC', NULL, '104.166.80.151', 'Mozilla/5.0 (X11; Linux i686; rv:109.0) Gecko/20100101 Firefox/120.0', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiSW9tdjl2T1JvUjhOeFdUcERXamJSU24yaFF1N0x0dEpKQWxOWWRwWiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTU6Imh0dHBzOi8vampndi5ldSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1730217971);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `users`
--

CREATE TABLE `users` (
  `id` bigint UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `two_factor_secret` text COLLATE utf8mb4_unicode_ci,
  `two_factor_recovery_codes` text COLLATE utf8mb4_unicode_ci,
  `two_factor_confirmed_at` timestamp NULL DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `current_team_id` bigint UNSIGNED DEFAULT NULL,
  `profile_photo_path` varchar(2048) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `two_factor_secret`, `two_factor_recovery_codes`, `two_factor_confirmed_at`, `remember_token`, `current_team_id`, `profile_photo_path`, `created_at`, `updated_at`) VALUES
(1, 'Aurora Guerra', 'fvilla@example.net', '2024-10-11 10:20:13', '$2y$12$vaCuMmgxlVzxylJbwvMPgOv9w9omBto9Tw2Uqh8y14oCvgFjZY/re', NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, 'default.png', NULL, NULL),
(2, 'Lic. Luis Santamaría', 'naiara.requena@example.net', '2024-10-11 10:20:14', '$2y$12$vaCuMmgxlVzxylJbwvMPgOv9w9omBto9Tw2Uqh8y14oCvgFjZY/re', NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, 'john_lennon.png', NULL, NULL),
(3, 'Asier Garibay', 'agosto.sofia@example.net', '2024-10-11 10:20:14', '$2y$12$vaCuMmgxlVzxylJbwvMPgOv9w9omBto9Tw2Uqh8y14oCvgFjZY/re', NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, 'perrito.png', NULL, NULL),
(4, 'Lic. Jon Alanis Segundo', 'ocastro@example.net', '2024-10-11 10:20:14', '$2y$12$vaCuMmgxlVzxylJbwvMPgOv9w9omBto9Tw2Uqh8y14oCvgFjZY/re', NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, 'tim-logo.png', NULL, NULL),
(5, 'Alejandro Matos Tercero', 'rodarte.veronica@example.com', '2024-10-11 10:20:14', '$2y$12$vaCuMmgxlVzxylJbwvMPgOv9w9omBto9Tw2Uqh8y14oCvgFjZY/re', NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, 'default.png', NULL, NULL),
(6, 'María Pilar García', 'erik.figueroa@example.org', '2024-10-11 10:20:14', '$2y$12$vaCuMmgxlVzxylJbwvMPgOv9w9omBto9Tw2Uqh8y14oCvgFjZY/re', NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, 'john_lennon.png', NULL, NULL),
(7, 'Cristian Olvera Segundo', 'archuleta.josemanuel@example.com', '2024-10-11 10:20:14', '$2y$12$vaCuMmgxlVzxylJbwvMPgOv9w9omBto9Tw2Uqh8y14oCvgFjZY/re', NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, 'perrito.png', NULL, NULL),
(8, 'Ainhoa Almaráz', 'snevarez@example.org', '2024-10-11 10:20:14', '$2y$12$vaCuMmgxlVzxylJbwvMPgOv9w9omBto9Tw2Uqh8y14oCvgFjZY/re', NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, 'tim-logo.png', NULL, NULL),
(9, 'Srta. Esther Arriaga', 'hprieto@example.com', '2024-10-11 10:20:14', '$2y$12$vaCuMmgxlVzxylJbwvMPgOv9w9omBto9Tw2Uqh8y14oCvgFjZY/re', NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, 'perrito.png', NULL, NULL),
(10, 'Ángel Sotelo Hijo', 'ruelas.fatima@example.net', '2024-10-11 10:20:14', '$2y$12$vaCuMmgxlVzxylJbwvMPgOv9w9omBto9Tw2Uqh8y14oCvgFjZY/re', NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, 'perrito.png', NULL, NULL),
(11, 'Susan', 'susan@example.com', '0000-00-00 00:00:00', '$2y$12$20KQXCy4ePhdo7LaNnqUc.4Zy.gEAWRNcGRdmz6cOA1o8x.GmI2oi', NULL, NULL, '0000-00-00 00:00:00', '', 2024, 'tim-logo.png', NULL, NULL);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `cache`
--
ALTER TABLE `cache`
  ADD PRIMARY KEY (`key`);

--
-- Indices de la tabla `cache_locks`
--
ALTER TABLE `cache_locks`
  ADD PRIMARY KEY (`key`);

--
-- Indices de la tabla `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `category_post`
--
ALTER TABLE `category_post`
  ADD PRIMARY KEY (`id`),
  ADD KEY `category_post_post_id_foreign` (`post_id`),
  ADD KEY `category_post_category_id_foreign` (`category_id`);

--
-- Indices de la tabla `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indices de la tabla `general_config`
--
ALTER TABLE `general_config`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `jobs`
--
ALTER TABLE `jobs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `jobs_queue_index` (`queue`);

--
-- Indices de la tabla `job_batches`
--
ALTER TABLE `job_batches`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `password_reset_tokens`
--
ALTER TABLE `password_reset_tokens`
  ADD PRIMARY KEY (`email`);

--
-- Indices de la tabla `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Indices de la tabla `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `sessions`
--
ALTER TABLE `sessions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sessions_user_id_index` (`user_id`),
  ADD KEY `sessions_last_activity_index` (`last_activity`);

--
-- Indices de la tabla `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `categories`
--
ALTER TABLE `categories`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT de la tabla `category_post`
--
ALTER TABLE `category_post`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT de la tabla `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `general_config`
--
ALTER TABLE `general_config`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `jobs`
--
ALTER TABLE `jobs`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT de la tabla `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `posts`
--
ALTER TABLE `posts`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT de la tabla `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `category_post`
--
ALTER TABLE `category_post`
  ADD CONSTRAINT `category_post_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `category_post_post_id_foreign` FOREIGN KEY (`post_id`) REFERENCES `posts` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
